'use strict'
module.exports = {
  NODE_ENV: '"production"',
  //change this to production URL 
  BASE_URL: '"https://church.nanocomputing.co.ke"'
}
